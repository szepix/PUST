clear all;
%pid & dmc
%przygotowanie ogólne
k_max = 449;
k_skok = 250;
k_start = 20;
Y_pp = 0.0;
U_pp = 0.0;
E=0;
y_zad = 1;  %(da się od 2 do 3 prawie)
Y_zad = zeros(k_max,1);
Y = zeros(k_max,1);
% U_max = 1.6;
% U_min = 0.6;
% DU_max = 0.1;
for k = 1:k_max
   if(k<=k_skok)
       Y_zad(k) = Y_pp;
   else
       Y_zad(k) = y_zad;
   end
end

%przygotowanie DMC
D=100; %horyzont dynamiki
N=20; %horyzont predykcji
Nu=10; %horyzont sterowania
% lambda=1; %lambda
lambda_u1 = 10;
lambda_u2 = 10;
psi_y1 = 1;
psi_y2 = 1;
DUP = zeros(D-1, 1);

%odp skok
fig11 = openfig('skok_u1_y1.fig');
axObjs11 = fig11.Children;
dataObjs11 = axObjs11.Children;
S_raw11 = dataObjs11(1).YData;
S11 = (S_raw11-S_raw11(1))/0.1;  %conversion!!!
s_odp11(1:100)=S11(1:100);
s_odp11(100+1:10000)=s_odp11(100);

fig21 = openfig('skok_u1_y2.fig');
axObjs21 = fig21.Children;
dataObjs21 = axObjs21.Children;
S_raw21 = dataObjs21(1).YData;
S21 = (S_raw21-S_raw21(1))/0.1;  %conversion!!!
s_odp21(1:100)=S21(1:100);
s_odp21(100+1:10000)=s_odp21(100);

fig12 = openfig('skok_u2_y1.fig');
axObjs12 = fig12.Children;
dataObjs12 = axObjs12.Children;
S_raw12 = dataObjs12(1).YData;
S12 = (S_raw12-S_raw12(1))/0.1;  %conversion!!!
s_odp12(1:74)=S12(1:74);
s_odp12(74+1:10000)=s_odp12(74);

fig22 = openfig('skok_u2_y2.fig');
axObjs22 = fig22.Children;
dataObjs22 = axObjs22.Children;
S_raw22 = dataObjs22(1).YData;
S22 = (S_raw22-S_raw22(1))/0.1;  %conversion!!!
s_odp22(1:74)=S22(1:74);
s_odp22(74+1:10000)=s_odp22(74);


%Mp
Mp = zeros(2*N, 2*(D-1));
for i=1:N
   for j=1:D-1
       Mp(2*i-1, 2*j-1)=s_odp11(i+j)-s_odp11(j);
       Mp(2*i-1, 2*j)=s_odp12(i+j)-s_odp12(j);
       Mp(2*i, 2*j-1)=s_odp21(i+j)-s_odp21(j);
       Mp(2*i, 2*j)=s_odp22(i+j)-s_odp22(j);
   end
end

%M
M = zeros(2*N, 2*Nu);
for i=1:N
   for j=1:min(i, Nu)
       M(2*i-1, 2*j-1)=s_odp11(i-j+1);
       M(2*i-1, 2*j)=s_odp12(i-j+1);
       M(2*i, 2*j-1)=s_odp21(i-j+1);
       M(2*i, 2*j)=s_odp22(i-j+1);
   end
end

%lambda
LAMBDA = eye(2*Nu).*repmat([lambda_u1 lambda_u2]',Nu,1);
PSI = eye(2*N).*repmat([psi_y1 psi_y2]',N,1);
%K
K=( (M'*PSI*M+LAMBDA)^-1 )*M'*PSI;
%do tej pory jasne

% Ke = sum(K(1,:));
% Ku = K(1,:)*Mp;

% Ku = K(1:2,:)*Mp;
Ku11 = zeros(1, D-1);
Ku21 = zeros(1, D-1);
Ku12 = zeros(1, D-1);
Ku22 = zeros(1, D-1);

Ke = zeros(2);

for i = 1:2     %out
    for j = 1:2 %in
        Ke(i,j) = sum(K(i,j:2:N*2));
    end
end

for i = 1:D-1
   Ku11(i) = K(1, 1:2:2*N)*Mp(1:2:2*N, 2*i-1);
   Ku21(i) = K(2, 1:2:2*N)*Mp(2:2:2*N, 2*i-1);
   Ku12(i) = K(1, 2:2:2*N)*Mp(1:2:2*N, 2*i);
   Ku22(i) = K(2, 2:2:2*N)*Mp(2:2:2*N, 2*i);
end

 
% fprintf('%f, ',Ku);
% fprintf('\n');
% fprintf('%f, ',zeros(1,D-1));
% fprintf('\n');

for i = 1 :length(Ku11)
    format longG
    KKu11 = "Ku11["+(i-1)+"] :=" + sprintf('%.6f',Ku11(i)) +";"+'\n';
%     dlmwrite('KU1.txt', Ku1, '-append');
    fprintf(KKu11);
%     writelines(Ku1,"KU1.txt", WriteMode="append");
end

for i = 1 :length(Ku21)
    format longG
    KKu21 = "Ku21["+(i-1)+"] :=" + sprintf('%.6f',Ku21(i)) +";"+'\n';
%     dlmwrite('KU1.txt', Ku1, '-append');
    fprintf(KKu21);
%     writelines(Ku1,"KU1.txt", WriteMode="append");
end

for i = 1 :length(Ku12)
    format longG
    KKu12 = "Ku12["+(i-1)+"] :=" + sprintf('%.6f',Ku12(i)) +";"+'\n';
%     dlmwrite('KU1.txt', Ku1, '-append');
    fprintf(KKu12);
%     writelines(Ku1,"KU1.txt", WriteMode="append");
end

for i = 1 :length(Ku22)
    format longG
    KKu22 = "Ku22["+(i-1)+"] :=" + sprintf('%.6f',Ku22(i)) +";"+'\n';
%     dlmwrite('KU1.txt', Ku1, '-append');
    fprintf(KKu22);
%     writelines(Ku1,"KU1.txt", WriteMode="append");
end




